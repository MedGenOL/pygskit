This folder comprises a Hail (www.hail.is) native Table or MatrixTable.
  Written with version 0.2.120-f00f916faf78
  Created at 2025/02/26 16:36:38